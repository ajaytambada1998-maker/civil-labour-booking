import 'package:flutter/material.dart';

void main() => runApp(const CivilLabourBookingApp());

class CivilLabourBookingApp extends StatelessWidget {
  const CivilLabourBookingApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'Civil Labour Booking',
    theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: Colors.orange), useMaterial3: true),
    home: const HomePage(),
  );
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Civil Labour Booking')),
    body: Padding(
      padding: const EdgeInsets.all(20),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        const Text('Palghar, Maharashtra', style: TextStyle(fontSize: 18)),
        const SizedBox(height: 20),
        const Text('Find and book construction workers', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        const SizedBox(height: 24),
        for (final role in ['Worker Registration', 'Contractor Registration', 'Worker Search', 'My Bookings', 'Admin'])
          Padding(padding: const EdgeInsets.only(bottom: 12), child: OutlinedButton(onPressed: () => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$role - setup pending'))), child: Text(role))),
      ]),
    ),
  );
}
