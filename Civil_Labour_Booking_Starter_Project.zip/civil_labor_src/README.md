# Civil Labour Booking (Flutter starter)

Starter scaffold for the Palghar labour booking app. Not production-ready.

## Setup
1. Install Flutter SDK and create a Flutter project, or use this starter in a Flutter environment.
2. Add `supabase_flutter` to dependencies.
3. Configure Supabase URL and publishable key (never put service-role keys in mobile code).
4. Apply `supabase/schema.sql` in Supabase SQL Editor.

This starter does not yet include real SMS provider setup, worker search, booking workflow, payments, notifications, or production security review.
